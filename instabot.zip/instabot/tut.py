from instapy import InstaPy
from instapy import smart_run

insta_username = "xtremepentest"
#insta_password = "981226jecha"
insta_password = "P4$$W0RD"


session = InstaPy(username=insta_username,
                  password=insta_password,
                  headless_browser=False)

with smart_run(session):
    session.set_relationship_bounds(enabled=True,
                                    delimit_by_numbers=True,
                                    max_followers=500,
                                    min_followers=30,
                                    min_following=50)
    session.set_do_follow(True, percentage=100)
    session.set_dont_like(['nsfw', 'kia', 'ford'])
    session.like_by_tags(['music', 'poetry', 'motivation', 'inspiration'], amount=10)
    